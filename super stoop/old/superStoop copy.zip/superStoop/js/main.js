
//jquery - datepicker
$(function() {
	$( "#datepicker" ).datepicker({
		minDate: 0,
		dateFormat: 'mm-dd--yy',
		altField: "#alternate",
		altFormat: "DD, d MM, yy",
		onSelect: function(){
			var day = $("#datepicker").datepicker('getDate').getDate();                 
            var month = $("#datepicker").datepicker('getDate').getMonth() + 1;             
            var year = $("#datepicker").datepicker('getDate').getFullYear();
            var fullDate = year + "-" + month + "-" + day;
			document.getElementById("datepicker").setAttribute("name", fullDate);
		}
	});
});


<html>
<body>

<?php
/*
**
*This page will receive the info from the form submitted by connect.php
*and add that data to the table.
**
*/
//receive the values
$username = $_POST['username'] ;
$password = $_POST['password'] ;
$firstName = $_POST['firstName'] ;
$lastName = $_POST['lastName'] ;
$theMonth = $_POST['theMonth'] ;
$theDay = $_POST['theDay'] ;
$theYear = $_POST['theYear'] ;
$theGender = $_POST['theGender'] ;
$theAddress = $_POST['theAddress'] ;
$theCity = $_POST['theCity'] ;
$theState = $_POST['theState'] ;
$theZip = $_POST['theZip'] ;
$theEmail = $_POST['theEmail'] ;
$active = 1;
$admin = 0;

	//variables
	$mysql_host = "localhost";
	$mysql_user = "root";
	$mysql_password = "";
	$mysql_db = "CISC";
	
	/**********TRY TO CONVERT TO DATE TYPE TO PASS IT TO THE TABLE**************/
	$bday = "$theYear-$theMonth-$theDay";
	echo "bday = " . $bday . "\n";
	$bday = strtotime($bday);
	echo "strtotime(bday) = " . $bday . "\n";
	$date = date('Y-m-d h:i:s',$bday );
	echo "theMonth: $theMonth, theDay: $theDay, theYear: $theYear";
	/***************************************************************************/
	
	// stablish a connection to mySQL
	$conn=mysql_connect($mysql_host,$mysql_user,$mysql_password) or die('Could not connect: '.mysql_error());
	// select a database
	mysql_select_db( $mysql_db ) or die( "Could not select database" );

	if( !empty($username) && !empty($password) ){
		$query = "INSERT INTO members (username, password, firstName, lastName, theBday, theGender, theEmail, active, admin) VALUES (
				'" . $username . "',
				'" . $password . "',
				'" . $firstName . "',
				'" . $lastName . "',
				'" . $date . "',
				'" . $theGender . "',
				'" . $theEmail . "',
				'" . $active . "',
				'" . $admin . "')";
		
		mysql_query($query) or die( "Query failed inserting new member: ". mysql_error() );
		echo "Number of People added to the table: " . mysql_affected_rows() . "</br>";
		$id = mysql_insert_id();
		//PDO::lastInsertId ();
	}

	//retrieve the personID of this person
	if(!empty($theZip)){
		$query = "INSERT INTO address (memberID, zip, theAddress) VALUES (
				'" . $id . "',
				'" . $theZip . "',
				'" . $theAddress . "')";
		
		mysql_query($query) or die( "Query failed: ". mysql_error() );
		echo "Number of Addresses added to the table: " . mysql_affected_rows() . "</br>";
	}

//SHOW MEMBERS TABLE
echo "<h3>Members Table</h3>\n";
$query = "SELECT * FROM members";
$result = mysql_query( $query ) or die( "Query failed: ". mysql_error() );
	echo "<table border=\"1\">\n";
	echo "\t<tr>\n";
	echo "\t\t<td>memberID</td>\n";
	echo "\t\t<td>username</td>\n";
	echo "\t\t<td>password</td>\n";
	echo "\t\t<td>firstName</td>\n";
	echo "\t\t<td>lastName</td>\n";
	echo "\t\t<td>theBday</td>\n";
	echo "\t\t<td>theGender</td>\n";
	echo "\t\t<td>theEmail</td>\n";
	echo "\t\t<td>active</td>\n";
	echo "\t\t<td>admin</td>\n";
	echo "\t</tr>\n";
	while ( $row = mysql_fetch_array( $result, MYSQL_ASSOC )) {
		echo "\t<tr>\n";
		foreach ( $row as $item ) {
			echo "\t\t<td>$item</td>\n";
		}
		echo "\t</tr>\n";
	}
	echo "</table>\n";
mysql_free_result( $result );

//SHOW ADDRESS TABLE
echo "<h3>Address Table</h3>\n";
$query = "SELECT * FROM address";
$result = mysql_query( $query ) or die( "Query failed: ". mysql_error() );
	echo "<table border=\"1\">\n";
	while ( $row = mysql_fetch_array( $result, MYSQL_ASSOC )) {
		echo "\t<tr>\n";
		foreach ( $row as $item ) {
			echo "\t\t<td>$item</td>\n";
		}
		echo "\t</tr>\n";
	}
	echo "</table>\n";
mysql_free_result( $result );



//close the connection
mysql_close($conn);

?>

</body>
</html>

<!DOCTYPE html>
<head>
</head>
<body>
	<h1>ADMIN SETTINGS</h1>
</body>
</html>
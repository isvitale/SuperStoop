<?php

	//variables
	$mysql_host = "mysql13.000webhost.com";
	$mysql_user = "a5325777_root";
	$mysql_password = "password1";
	$mysql_db = "a5325777_CISC";

	// stablish a connection to mySQL
	$conn=mysql_connect($mysql_host,$mysql_user,$mysql_password) or die('Could not connect: '.mysql_error());
	// select a database
	mysql_select_db( $mysql_db ) or die( "Could not select database" );

?>